# Scala_Final_Project
Enriched STM GTFS data set with Scala

To Demo app run please run EnricherTrip

STM GTFS data set are found in the Data folder. 

The Generated output file is labelled enricher-trip.text and its also found in the Data folder.
